#!/usr/bin/env python3

from __future__ import print_function

import sys
import rospy
from turtlesim.srv import Spawn

def spawn_turtle(x, y, theta):
    rospy.wait_for_service('/spawn')
    try:
        spawn_service = rospy.ServiceProxy('/spawn', Spawn)
        resp = spawn_service(x, y, theta, turtle)
        return resp.name
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

if __name__ == "__main__":
    args = rospy.myargv(argv=sys.argv)
    if len(args) == 5:
        x = float(args[1])
        y = float(args[2])
        theta = float(args[3])
        turtle = args[4]
    else:
        print("pass valid number of arguments")
        sys.exit(1)
    spawn_turtle(x, y, theta)
