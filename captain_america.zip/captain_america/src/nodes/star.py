#!/usr/bin/env python
# license removed for brevity
import rospy
from geometry_msgs.msg import Twist
import sys

def trace_star(turtle):
    pub = rospy.Publisher('/'+turtle+'/cmd_vel', Twist, queue_size=10)
    rospy.init_node('circle', anonymous=True)
    rate = rospy.Rate(0.8) # 10hz
    i=0
    while not rospy.is_shutdown():
        command = Twist()
        
        command.linear.y = 0.0
        command.linear.z = 0.0
        command.angular.x = 0.0
        command.angular.y = 0.0

        if i%2==0:
            command.linear.x = 5.0
            command.angular.z = 0.0
        else:
            command.linear.x = 0.0
            command.angular.z = -2.495

        rospy.loginfo(command)
        pub.publish(command)
        rate.sleep()
        i+=1

if __name__ == '__main__':
    args = rospy.myargv(argv=sys.argv)
    try:
        if len(args) == 2:
            turtle = args[1]
            trace_star(turtle)
        else:
            print("pass valid number of arguments")
            sys.exit(1)

    except rospy.ROSInterruptException:
        pass
