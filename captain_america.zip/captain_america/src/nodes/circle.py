#!/usr/bin/env python
# license removed for brevity
import rospy
from geometry_msgs.msg import Twist
import sys

def trace_circle(turtle, radius):
    pub = rospy.Publisher('/'+turtle+'/cmd_vel', Twist, queue_size=10)
    rospy.init_node('circle', anonymous=True)
    rate = rospy.Rate(1) # 10hz
    while not rospy.is_shutdown():
        command = Twist()

        linear_velocity = 5.0

        command.linear.x = linear_velocity
        command.linear.y = 0.0
        command.linear.z = 0.0
        command.angular.x = 0.0
        command.angular.y = 0.0
        command.angular.z = -linear_velocity/radius

        rospy.loginfo(command)
        pub.publish(command)
        rate.sleep()

if __name__ == '__main__':
    args = rospy.myargv(argv=sys.argv)
    try:
        if len(args) == 3:
            turtle = args[1]
            radius = float(args[2])
            trace_circle(turtle, radius)
        else:
            print("pass valid number of arguments")
            sys.exit(1)

    except rospy.ROSInterruptException:
        pass
